#!/usr/bin/env python

import profile
profile.run("execfile('checkmail.py')", 'bobby')

import pstats
p = pstats.Stats('bobby')
# --
#print '--'
#p.sort_stats('name').print_stats()
# --
#print '--'
#p.sort_stats('cumulative').print_stats()
# --
#print '--'
#p.sort_stats('time').print_stats()
# --
print '--'
p.strip_dirs()
p.sort_stats('name')
p.print_callers()
# --

#eof
