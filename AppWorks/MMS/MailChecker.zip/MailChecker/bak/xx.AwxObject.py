true = 1
false = 0

def dumptextfile(filename, strip=false):
	l = open(filename).readlines()
	if strip:
		return map(lambda e: e[:-1], l)
	else:
		return l

def nequals(s1, s2):
	return s1[:len(s2)] == s2

class AwxObject:
  pass

#eof
