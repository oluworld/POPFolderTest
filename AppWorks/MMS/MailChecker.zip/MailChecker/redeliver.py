import sys, os
from MMSTransfer import MMSTransfer
from AwxDBiServer import DBiServer
from etoffiutils import dumptextfile, true, false
from MailChecker import ConsoleUI

def main():
	Root = '/local/DBi/.config/email/sources'

	myDBi=DBiServer

	# --
	account_name     = sys.argv[1] # softhome, yahoo
	source_folder    = 'root' 		# sys.argv[2]
#	target_folder    = sys.argv[3]
	frr = myDBi.getStr(Root+'/'+account_name)
	print frr
	fr  = myDBi.getStr(Root+'/'+account_name+'/folderroot') #.value
#	print fr
#	print source_folder
	_f5 = os.listdir(os.path.join(fr, source_folder))
#	print _f5
	message_num_list = map(lambda e: e[:-4], filter(lambda e: e[-4:]=='.msg', _f5))
	# --
	T = MMSTransfer(fr, myDBi)
##	T.test()
	mnll=len(message_num_list)
	cur=1
	ui=ConsoleUI()
	for each in message_num_list:
		fn = os.path.join(T.fr,source_folder,each+'.msg')
		r  = dumptextfile(fn)
##		print r
		
		T.transfer(ui, r, put_fromline=false)
		ui.tell('Redelivering message %s [%d of %d]' % (each, cur, mnll))
## 		T.writeMsg(r, '.moved-trash', false)
		os.unlink(fn)
		cur+=1
	
main()
