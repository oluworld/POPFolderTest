#from AwxDBiServer import getDBiServer
from DBiValue import *
from etoffiutils import xstat, progressiveParse, true, false
import string

DBiServer = None

def string_right(str, len):
	return str[-len:]
def checkRemoveEnd(instr, endwith):
	le = len(endwith)
	if string_right(instr,le)==endwith:
		rv=instr[:-le]
	else:		
		rv=instr
	return rv
def getQuoted(line):
	i = 1
	ch = line[:1]
	while line[i:i+1] != ch:
		if line[i:i-1] == '\\':
			continue
		i = i + 1
	return line[1:i], line[i+2:]

def SplitLine(line):
	name = ''
	value = ''

	if line[:1] == '"':
		name, value = getQuoted(line)
	else:
		while line[:1] not in (' ', '\t') and len(line):
			name = name + line[:1]
			line = line[1:]
		value = line[1:]

	if value[:1] in ('"', "'"):
		value = value[1:-1]
#	else:
#		value = value[1:]
		
	return (name, value)

class RCDBiHandler:
	RCEXT = '.rc'
	RCSIG = None

	def __init__(self, srv):
		self._files = {}
		self.locked = false
		global DBiServer
		DBiServer = srv
	def Begin(self, root):
		# Begin(root:STRING)->None
		try:
			self._Begin(root)
		except IOError, e:
			print e
	def GetOutFile(self, root, mode='wb'):
		return open(self.GetFileName(root), mode)
	def GetFileName(self, root):
		if root[:2] == '~/':
			Root = "%s%s%s" % (DBiServer.DBIROOT, root[2:], self.RCEXT)
		elif root[:11] == '/local/DBi/':
			Root = "%s%s%s" % (DBiServer.DBIROOT, root[11:], self.RCEXT)
		else:
			Root = '%s%s' % (root, self.RCEXT)
		return Root
	def __str__(self):
		return '<RCDBiHandler >'
	def getValue(self, path):
		rv = None
		for each in progressiveParse(path, '/'):
			each=checkRemoveEnd(each, '/')
			fn=self.GetFileName(each)
			if xstat(fn): 
				self.lock()
				self._Begin(each)
				rv = self.locker[path]
				self.unlock()
				break
		return rv
	def lock(self):
		self.locker={}
		self.locked=true
	def unlock(self):
		self.locker={}
		self.locked=false
	def add_to_locker(self, value):
		if self.locked:
			self.locker[value.path]=value
	def canOpen(self, root):
		for each in progressiveParse(root, '/'):
			each=checkRemoveEnd(each, '/')
			fn=self.GetFileName(each)
##			print 'EACH '+each
##			print 'STAT '+fn
			if xstat(fn): 
				return true
		return false
	def _Begin(self, root):
		## TODO: this function is capable of opening *any* file on a system!!!
		root=checkRemoveEnd(root,'/')
		Root=self.GetFileName(root)
		s = open(Root, 'r')

		if not self._files.has_key(root):
			self._files[root] = {}
			self._files[root]['max'] = 0
			
##		print '%% RCDBiHandler._Begin: (%s)==(%s)' % (root, Root)
			
		if self.RCSIG:
			if s.readline() != self.RCSIG:
				if s.readline() != self.RCSIG:
					return

		r = ''

		linenum = 0 # one based!!!
		while r != None:
			line = s.readline()
			if not line: break

			linenum = linenum + 1

			if line[:-1] == '\\':
				line[:-1] = ''
				linenum = linenum - 1
				continue

			(name, value) = SplitLine(line[:-1])

			newval = DBiValue(root+'/'+name, value, self, (root, linenum))
			self._files[root][linenum]=newval
			self._files[root]['max']=max(self._files[root]['max'], linenum)
			DBiServer.add(newval)
			self.add_to_locker(newval)

	def End(self, root):
		R=self._files[root]
		F=self.GetOutFile(root)
		for each in xrange(1, self._files[root]['max']+1):
			L=R[each]
			L_name=L.path[string.rindex(L.path, '/')+1:]
			for each in (' ', '\n', '\r', '\t', "'", '=', '"'):
				if each in L_name:
					if each == '"':
						L_name = "'%s'" % L_name
					else:
						L_name = '"%s"' % L_name
					break
			F.write('%s %s\012' % (L_name, L.value))
		R=None
		del self._files[root]		

#eof
