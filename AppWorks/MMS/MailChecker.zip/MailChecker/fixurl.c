#include <Python.h>
#include <ctype.h>

/* OK, now define a decent interface to ctype macros.  The regular
   ones misfire when you feed them chars >= 127, as they understand
   them as "negative", which results in out-of-bound access at
   table-lookup, yielding random results.  This is, of course, totally
   bogus.  One way to "solve" this is to use `unsigned char'
   everywhere, but it is nearly impossible to do that cleanly, because
   all of the library functions and system calls accept `char'.

   Thus we define our wrapper macros which simply cast the argument to
   unsigned char before passing it to the <ctype.h> macro.  These
   versions are used consistently across the code.  */

#ifndef __cplusplus
#	define ISXDIGIT(x) isxdigit ((unsigned char)(x))

/* ASCII char -> HEX digit */
#	define ASC2HEXD(x) \
		(((x) >= '0' && (x) <= '9') ? ((x) - '0') : (toupper(x) - 'A' + 10))
/* HEX digit -> ASCII char */
#	define HEXD2ASC(x) (((x) < 10) ? ((x) + '0') : ((x) - 10 + 'A'))
#	define ARRAY_SIZE(array) (sizeof (array) / sizeof (*(array)))
#else
#	define ISXDIGIT(x) isxdigit ((unsigned char)(x))

/* ASCII char -> HEX digit */
#	define ASC2HEXD(x) \
		(((x) >= '0' && (x) <= '9') ? ((x) - '0') : (toupper(x) - 'A' + 10))
/* HEX digit -> ASCII char */
#	define HEXD2ASC(x) (((x) < 10) ? ((x) + '0') : ((x) - 10 + 'A'))
#	define ARRAY_SIZE(array) (sizeof (array) / sizeof (*(array)))
#endif

#ifndef WINDOWS
# define URL_UNSAFE " <>\"#|\\^~[]`@:\033?"
#else  /* WINDOWS */
# define URL_UNSAFE " <>\"%{}|\\^[]`\033"
#endif /* WINDOWS */

/* xmalloc, xrealloc and xstrdup exit the program if there is not
   enough memory.  xstrdup also implements strdup on systems that do
   not have it.  */
void *
xmalloc (size_t size)
{
	void *res;
	
	res = malloc (size);
	if (!res)
		memfatal ("malloc");
	return res;
}

void
xfree(void *ptr)
{
	free(ptr);
}

/* Decodes the forms %xy in a URL to the character the hexadecimal
   code of which is xy.  xy are hexadecimal digits from
   [0123456789ABCDEF] (case-insensitive).  If x or y are not
   hex-digits or `%' precedes `\0', the sequence is inserted
   literally.  */

static char *
decode_string (char *s)
{
	char *pp = strdup(s), *p = pp;

	for (; *s; s++, p++)
	{
		if (*s != '%')
			*p = *s;
		else
		{
			/* Do nothing if at the end of the string, or if the chars
			   are not hex-digits.  */
			if (!*(s + 1) || !*(s + 2)
    				|| !(ISXDIGIT (*(s + 1)) && ISXDIGIT (*(s + 2))))
			{
				*p = *s;
				continue;
			}
			*p = (ASC2HEXD (*(s + 1)) << 4) + ASC2HEXD (*(s + 2));
			s += 2;
		}
	}
	*p = '\0';
	return pp;
}


/* Encodes the unsafe characters (listed in URL_UNSAFE) in a given
   string, returning a malloc-ed %XX encoded string.  */
char *
encode_string (const char *s)
{
	const char *b;
	char *p, *res;
	int i;

	b = s;
	for (i = 0; *s; s++, i++)
		if (strchr (URL_UNSAFE, *s))
			i += 2; /* Two more characters (hex digits) */

	res = (char *)xmalloc (i + 1);
	s = b;
	for (p = res; *s; s++)
		if (strchr (URL_UNSAFE, *s))
		{
			const unsigned char c = *s;
			*p++ = '%';
			*p++ = HEXD2ASC (c >> 4);
			*p++ = HEXD2ASC (c & 0xf);
		}
		else
			*p++ = *s;
	*p = '\0';
	return res;
}

static PyObject *
fixurl_encode(PyObject *self, PyObject *args)
{
	char *instr, *res;

	if (!PyArg_ParseTuple(args, "s", &instr))
		return NULL;
	res = encode_string(instr);

    return Py_BuildValue("s", res);
}

static PyObject *
fixurl_decode(PyObject *self, PyObject *args)
{
	char *instr, *res;

	if (!PyArg_ParseTuple(args, "s", &instr))
		return NULL;
	res = decode_string(instr);

    return Py_BuildValue("s", res);
}

static PyMethodDef fixurlMethods[] = {
    {"encode",  fixurl_encode, METH_VARARGS},
    {"decode",  fixurl_decode, METH_VARARGS},
    {NULL,      NULL}        /* Sentinel */
};

void 
initfixurl()
{
	PyObject *m = Py_InitModule("fixurl", fixurlMethods);
}
