from DBiValue import *
from MMSTransfer import *
from MMSUI import *
from AwxDBi import *
from AwxDBiServer import DBiServer
from MMSBase import *

class MailChecker:
	def checkmail(self, getting = 1):
		def strsplit(instr, splitby):
			pos = instr.rfind(splitby)
			return instr[:pos], instr[pos+1:]
		Sources = []
		Sources = self.myDBi.enum('~/.config/email/sources', AwxDBi.EnumFlat)

		for each in Sources:
			root, acct_name = strsplit(each.path, '/')
			self.myDBi.setRoot(each.path)
			self.check_account(acct_name, getting)
			
	def check_account(self, acct_name, getting):
		"""
			
		"""
		if 1:
			#
			# Stage 1: Notify the user that we are here and attempt
			#          to get an MMSSource for the current server [each]
			#
			uimsg = 'getting mail from ' + self.myDBi.getStr('name')
			self.ui.tell(uimsg)

			clazz = ("MMS%sSource" % self.myDBi.getStr( 'type' ))
			src = MMSSourceFactory(clazz)
##			src = eval(clazz + '()')

			if not src:
				self.ui.abort("No such source: " + clazz)
				return

			#
			# Stage 2: Inform this generic source with the server's info
			#
			try:
				# enum the current folder (./ is not impl yet, so use blank)
				src.setFlags(self.myDBi.enum('', AwxDBi.EnumRecursive))
				src.login(self.ui, getting)
			except MMSLoginError, e:
				self.ui.abort(e.what())
				return

			#
			# Stage 3: Tell the user how many messages are available
			#          Skip server if there are no messages.
			#
			newmsgs, totmsgs = src.getMessageCount()

			if newmsgs == 0:
				self.ui.tell('No new messages. %d old messages' % totmsgs)
				return
			elif newmsgs == 1:
				self.ui.tell('1 new message')
			else:
				self.ui.tell('%d new messages' % newmsgs)

			#
			# Stage 4: Retrieve the messages, letting the user know the status 
			#          after each retrieval
			#
			if getting:
				T = MMSTransfer(acct_name, self.myDBi) ## who knows if this is right?

				for msgs in xrange(1, newmsgs + 1):
					self.ui.tell("Retrieving %d of %d" % (msgs, newmsgs) )
					msg = src.getMsg(msgs, self.deleting)

#					if not msg:
#						raise errEmptyMessage(self, src) # "MMSMailChecker::checkmail"

					self.onGetMsg(T, msg)

##			if self.deleting and self.getting:
##				for cur_msg in xrange(1, newmsgs + 1):
##					self.ui.tell("Deleting %d of %d" % (cur_msg, newmsgs) )
##					src.deleteMsg(cur_msg)

			#
			# Stage 5: Tell the user we are finished and logoff the server by
			#          ``finalizing" the source
			#
			self.ui.tell('Finished ' + uimsg)
			src.finalize()

	def __init__(self, deleting = 1, ui = None):
		self.deleting = deleting
		self.myDBi = AwxDBi()
#		self.myDBi = DBiServer
		if ui == None:
			self.ui = NullUI() #ConsoleUI()
		else:
			self.ui = ui

	def onGetMsg(self, T, msg):
		T.transfer(self.ui, msg)

#eof
