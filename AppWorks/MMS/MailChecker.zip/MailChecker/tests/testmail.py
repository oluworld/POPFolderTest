#!/usr/bin/env python
from MailChecker import *

def go():
	m = MailChecker(REMOVE_FROM_SERVER, ConsoleUI())
	m.checkmail(TEST_MODE)

go()

#eof
