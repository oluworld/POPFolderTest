import profile
profile.run("execfile('redeliver.py')", 'bobby')

import pstats
p = pstats.Stats('bobby')
# --
#print '--'
#p.sort_stats('name').print_stats()
# --
print '--'
p.sort_stats('cumulative').print_stats()
# --
print '--'
p.sort_stats('time').print_stats()
# --
#print '--'
#p.print_callers()
# --

