#!/usr/bin/env python
from RCDBiHandler import *
from AwxDBiServer import DBiServer

r = RCDBiHandler()
r.Begin('foo')
r.Begin('~/.config/email/sources')
r.Begin('q:/DBi/.config/email/sources')
r.Begin('~/.config/email/sources/001')


def xx(rr):
	r=DBiServer.getStrOrNil(rr)
	if r:
		print '%s = %s' % (rr, r.value)
	else:
		print '%s = None' % rr

xx('~/.config/email/sources')
xx('~/.config/email/sources/001/name')

r.End('foo')
r.End('~/.config/email/sources/001')

#eof
