import sys, os
from MMSTransfer import MMSTransfer
from AwxDBiServer import DBiServer
from etoffiutils import dumptextfile, true, false

def main():
	Root = '/local/DBi/.config/email/sources'

	myDBi=DBiServer

	fr=myDBi.getStr(Root+'/'+sys.argv[1]+'/folderroot').value
##	print fr
	T = MMSTransfer(fr)
	for each in sys.argv[4:]:
		fn = os.path.join(T.fr,sys.argv[2],each+'.msg')
		r  = dumptextfile(fn)
##		print r
		T.writeMsg(r, sys.argv[3], false)
		T.writeMsg(r, '.moved-trash', false)
		os.unlink(fn)
	
main()
