import string
from etoffiutils import *
from MMSMessage import MMSMessage
from MMSFolder import MMSFolder

# filterspec: <header> <rule> <action>
# header: 'Subject' ...
# rule: ['not'] 'contains'|'beginswith'|'endswith'
# action: 'moveto' <foldername>|'delete'

class MMSTransfer:
	def __init__(self, src, dbi=None):
		self._reset(src, dbi)
		
	def _reset(self, src, dbi):
		if dbi==None:
			from AwxDBi import *
			self.myDBi = AwxDBi()
		else:
			self.myDBi = dbi

		self._init() # initialize member variables
##		if type(src) == type(''):
##			self.fn = '%s/Filters.dat' % src
##			self.fr = src
##			self._init()
##		else:
##			print dbi
##			self.fn = dbi.getStr('filterfile', src.path)##.value
##			self.fr = dbi.getStr('folderroot', src.path)##.value
###			dbi.close() ## wrong!! AwxDBi is modeless!!	
##						## wrong!! No its not !!
##			self._readfilters()
		
		dbi.setRoot('/local/DBi/.config/email/sources/'+src)
		self.fn = dbi.getStr('filterfile')
		self.fr = dbi.getStr('folderroot')
		#dbi.close() 
		self._readfilters()

##	def __init__(self, src):
##		self.fn = '%s/Filters.dat' % src
##		self.fr = src
##		self._init()
##		self._readfilters()
		
	def _init(self):
		self.testing = false	# set testmode to off
		self.filters = []
		self.folders = {}
	def _readfilters(self):
		try:
			self.filters = filter(lambda e: len(e) and e[0][0]!='#', \
				quickReadFunc(self.fn, string.split, true))
		except IOError, e:
			if e.errno == 2:
				print "!!!!: no filters because no filterfile"
			else:
				print e

	def transfer(self, complaintbox, msg, Folder=None, put_fromline=true):
		if Folder == None:
			self.ApplyFilters(self.filters, msg, complaintbox, put_fromline)
		else:
			self.writeMsg(msg, Folder, put_fromline)

	def ApplyFilters(self, filters, msg, ui, put_fromline=true):
		""" go through each in $filters and see if we can pull up a 
			matching header for $msg. will report success to $ui
		"""
		# Subject contains litestep moveto litestep
		for each in filters:
			h = msg.GetHeader(each[0])

			if h and self.GetMatch(h, each[1:], msg):
##				ui.xtell('-- YES YES YES\n%s \n %s %s %s\n--' % (h, each[0], each[1], each[2]))
				ui.tell('-> %s' % each[4])
				self.Do(each[3:], msg, put_fromline)
				return
		self.writeMsg(msg, put_fromline=put_fromline)
	
	def GetMatch(self, header, rule, msg):
		# header -> '[Litestep] listsplitter 2000'
		# rule	 -> 'contains' '[Litestep]' 'moveto' 'litestep'
		# msg    -> ['From: ...', '...']

		cur = 0
		Negate = false
		if rule[1] == 'not':
			Negate = true
			cur = cur + 1

		if string.lower(rule[cur]) == 'contains':
			cur = cur + 1
			if string.find(header, rule[cur]) == -1:
				return false
			else:
				return true

		if rule[cur] == 'beginswith':
			cur = cur + 1
			if nequals(header, rule[cur]):
				return true
			else:
				return false

		if rule[cur] == 'endswith':
			cur = cur + 1
			if header[:len(rule[cur])] == rule[cur]:
				return true
			else:
				return false

		return false
	
	def test(self):
		self.testing = true
	
	def writeMsg(self, msg, folder_name='root', put_fromline=true):
		""" #writeMsg accepts a list of lines and dumps them to
			the next available slot (see #getNext, #GetNextFilename)
			in the folder $folder.	$put_fromline controls the possibility 
			to add a mbox-separator	to the top of the written file.
			a debug message is output in test mode.

			% ... 2.0 01-Jan-13 (1925) actor
		"""
		if self.testing == true:
##			print 'would have written message to folder %s' % folder
			return
		
		folder = self.getFolder(folder_name)
		folder.store(msg, put_fromline=put_fromline)

##		fp = '%s/%s' % (self.fr, folder_name)
##		ensure_directory_present(fp)
##
##		fn = self.GetNextFilename(self.GetNext(fp), fp)
##		f = open(fn, 'a+')
##		if put_fromline:
##			import time
##			f.write("From - %s\012" % time.ctime(time.time()) )
##		f.writelines(msg)
##		f.close()

	def getFolder(self, folder_name):
		""" 01-Jan-13 (1920) """
		if self.folders.has_key(folder_name):
			return self.folders[folder_name]
		else:
			rv = MMSFolder(folder_name, self.fr)
			self.folders[folder_name] = rv
			return rv

	def GetNextFilename(self, num, fp):
		return '%s/%s.msg' % (fp, self.makenum(num))

	def makenum(self, num):
		return Fill(num, '0', 4)
	
	def GetNext(self, _dirname):
		""" cruise a directory no find the first available file.
			this operation is skipped if the file `.next' is present.
			the name of the file is based on the funcion #makenum.
			this function will write an incremented number to `.next'
			if test mode is not on.
		"""
		filename = '%s/.next' % _dirname
		mn = 0
		try:
##			print read_firstline_from_file(filename)
			mnf = open(filename)
			llp = mnf.readline()[:-1]
			if llp:
				mn = int(llp)
			else:
				mn = 0
			mnf.close()
		except IOError, e:
			if e.errno != 2:
				print e
		except Exception, e:
			print e
		mn = inc_until_nofile_fn(mn, \
			lambda e, pre=_dirname+'/', self=self: '%s%s%s' % (pre, self.makenum(e), '.msg'))
		if self.testing == false:
			try:
				mnf = open(filename, 'w')
				mpn = mn+1
				mnf.write('%d\012' % mpn)
				mnf.close()
			except Exception, e:
				print e

		return mn

	def Do(self, Action, msg, put_fromline=true):
		""" #Do calls #writeMsg based on understood actions 
			% delegator
		"""
		if Action[0] == 'moveto':
			self.writeMsg(msg, Action[1], put_fromline=put_fromline)

		if Action[0] == 'copyto':
			self.writeMsg(msg, put_fromline=put_fromline)
			self.writeMsg(msg, Action[1], put_fromline=put_fromline)

		if Action[0] == 'delete':
			pass

##def test():
##	fldr = 'y:/data/email/TEST'
##	gpd  = GetPopDeliver(fldr)
##
##	m=0
##	for i in xrange(1452, 1552):
##		gpd.transfer(None, dumptextfile('y:/data/email/softhome/inbox-%d'%1552, true))
##		if m == 16:
##			os.system('command /c @rmm')
##			m=0
##		m = m+1
		
if __name__ == '__main__':
	test()
# eof
