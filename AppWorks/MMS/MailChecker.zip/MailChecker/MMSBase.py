import MMSPOPSource
from MMSError import *

REMOVE_FROM_SERVER  = 1
LEAVE_ON_SERVER     = 0

CONNECT_MODE        = 1
TEST_MODE           = 0


def MMSSourceFactory(clazzname):
	if clazzname == 'MMSPOPSource':
		return MMSPOPSource.MMSPOPSource()
